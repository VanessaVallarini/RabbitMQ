﻿namespace RabbitMQ2.Core.DTOs
{
    public class PaymentDTO
    {
        public int Id { get; set; }
        public decimal AmountToPay { get; set; }
        public string CardNumber { get; set; }
        public string Name { get; set; }
    }
}
