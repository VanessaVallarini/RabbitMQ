﻿namespace RabbitMQ2.Core.Entities
{
    public class Payment : BaseEntity
    {
        public Payment(decimal amountToPay, string cardNumber, string name)
        {
            AmountToPay = amountToPay;
            CardNumber = cardNumber;
            Name = name;
        }

        public decimal AmountToPay { get; private set; }
        public string CardNumber { get; private set; }
        public string Name { get; private set; }
    }
}
