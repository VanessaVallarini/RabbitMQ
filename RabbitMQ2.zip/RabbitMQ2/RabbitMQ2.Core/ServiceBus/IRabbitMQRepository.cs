﻿using RabbitMQ2.Core.Entities;

namespace RabbitMQ2.Core.ServiceBus
{
    public interface IRabbitMQRepository
    {
        void Close();
        void SendStandardExchange(Payment payment);
        void SendFanoutExchange(Payment payment);
        void SendDirecExchange(Payment payment);
        void SendTopicExchange(Payment payment);
    }
}
