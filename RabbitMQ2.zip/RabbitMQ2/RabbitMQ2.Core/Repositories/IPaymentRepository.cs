﻿using RabbitMQ2.Core.DTOs;
using RabbitMQ2.Core.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace RabbitMQ2.Core.Repositories
{
    public interface IPaymentRepository
    {
        Task AddAsync(Payment payment);
        Task<List<PaymentDTO>> GetLastPayments(int amount);
        Task SaveChangesAsync();
    }
}
