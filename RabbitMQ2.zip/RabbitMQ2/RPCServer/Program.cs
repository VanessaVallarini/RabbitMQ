﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;

namespace RPCServer
{
    //Chamada de procedimento remoto (RPC)
    //Se precisarmos executar uma função em um computador remoto e esperar o resultado?
    //Esse padrão é comumente conhecido como Remote Procedure Call ou RPC .
    //Como não temos tarefas demoradas que valham a pena distribuir,
    //vamos criar um serviço RPC fictício que retorna números de Fibonacci.
    //NOTA
    //Embora RPC seja um padrão bastante comum na computação, é frequentemente criticado.
    //Os problemas surgem quando um programador não sabe se uma chamada de função é local ou se
    //é um RPC lento.Confusões como essa resultam em um sistema imprevisível e adiciona
    //complexidade desnecessária à depuração.Em vez de simplificar o software, o RPC mal
    //utilizado pode resultar em código espaguete impossível de manter.
    //Tendo isso em mente, considere o seguinte conselho:
    //Certifique-se de que é óbvio qual chamada de função é local e qual é remota.
    //Documente seu sistema.Deixe claras as dependências entre os componentes.
    //Trate os casos de erro.Como o cliente deve reagir quando o servidor RPC ficar inativo
    //por muito tempo?
    //Em caso de dúvida, evite RPC. Se possível, você deve usar um pipeline assíncrono -
    //em vez de bloqueio do tipo RPC, os resultados são enviados de forma assíncrona para
    //um próximo estágio de computação.

    //Propriedades da mensagem
    //O protocolo AMQP 0-9-1 pré-define um conjunto de 14 propriedades que acompanham uma
    //mensagem.A maioria das propriedades raramente é usada, com exceção das seguintes:
    //Persistente : marca uma mensagem como persistente(com um valor verdadeiro) ou
    //transitória(qualquer outro valor). Dê uma olhada no segundo tutorial.
    //DeliveryMode : quem está familiarizado com o protocolo pode optar por usar
    //esta propriedade em vez de Persistent . Eles controlam a mesma coisa.
    //ContentType : usado para descrever o tipo mime da codificação. Por exemplo, para a
    //codificação JSON freqüentemente usada, é uma boa prática definir essa propriedade
    //como: application / json.
    //ReplyTo : normalmente usado para nomear uma fila de retorno de chamada.
    //CorrelationId : útil para correlacionar respostas RPC com solicitações - Neste exemplo
    //estamos criando uma única fila de retorno de chamada por cliente. Com essa propriedade 
    //podemos identificar as origens das solicitações.

    //O código do servidor é bastante simples:
    //Como de costume, começamos estabelecendo a conexão, o canal e declarando a fila.
    //Podemos querer executar mais de um processo de servidor.Para distribuir a carga igualmente por vários servidores, precisamos definir a configuração prefetchCount
    //em channel.BasicQos.
    //Usamos BasicConsume para acessar a fila.Em seguida, registramos um gerenciador de entrega no qual fazemos o trabalho e enviamos a resposta de volta.
    //O código do cliente é um pouco mais complicado:
    //Estabelecemos uma conexão e um canal e declaramos uma fila de 'retorno de chamada' exclusiva para respostas.
    //Assinamos a fila de 'retorno de chamada', para que possamos receber respostas RPC.
    //Nosso método Call faz a solicitação RPC real.
    //Aqui, primeiro geramos um número CorrelationId exclusivo e o salvamos para identificar a resposta apropriada quando ela chegar.
    //Em seguida, publicamos a mensagem de solicitação, com duas propriedades: ReplyTo e CorrelationId .
    //Nesse ponto, podemos sentar e esperar até que a resposta adequada chegue.
    //Para cada mensagem de resposta, o cliente verifica se CorrelationId é o que estamos procurando. Nesse caso, ele salva a resposta.
    //Por fim, retornamos a resposta ao usuário.

    //Nosso código ainda é bastante simplista e não tenta resolver problemas mais complexos(mas importantes), como:
        //Como o cliente deve reagir se não houver servidores em execução?
        //Um cliente deve ter algum tipo de tempo limite para o RPC?
        //Se o servidor não funcionar corretamente e gerar uma exceção, ele deve ser encaminhado ao cliente?
        //Proteção contra mensagens de entrada inválidas(por exemplo, verificação de limites, tipo) antes do processamento.
    public class Program
    {
        private static ConnectionFactory _factory;
        private static IConnection _connection;
        private static IModel channel;

        static void Main(string[] args)
        {
            _factory = new ConnectionFactory { HostName = "localhost", UserName = "guest", Password = "guest" };
            _connection = _factory.CreateConnection();
            channel = _connection.CreateModel();

            channel.QueueDeclare(queue: "rpc_queue", 
                                 durable: false,
                                 exclusive: false, 
                                 autoDelete: false, 
                                 arguments: null);

            channel.BasicQos(0, 1, false);

            var consumer = new EventingBasicConsumer(channel);

            channel.BasicConsume(queue: "rpc_queue",
                                 autoAck: false, 
                                 consumer: consumer);

            Console.WriteLine("Aguardando solicitações RPC....");

            consumer.Received += (model, ea) =>
            {
                string response = null;

                var body = ea.Body.ToArray();
                var props = ea.BasicProperties;
                var replyProps = channel.CreateBasicProperties();
                replyProps.CorrelationId = props.CorrelationId;

                try
                {
                    var message = Encoding.UTF8.GetString(body);
                    int n = int.Parse(message);
                    Console.WriteLine(" [.] fib({0})", message);
                    response = fib(n).ToString();
                }
                catch (Exception e)
                {
                    Console.WriteLine(" [.] " + e.Message);
                    response = "";
                }
                finally
                {
                    var responseBytes = Encoding.UTF8.GetBytes(response);
                    channel.BasicPublish(exchange: "", 
                                         routingKey: props.ReplyTo,
                                         basicProperties: replyProps, 
                                         body: responseBytes);

                    channel.BasicAck(deliveryTag: ea.DeliveryTag,
                                     multiple: false);
                }
            };
            Console.WriteLine(" Press [enter] to exit.");
            Console.ReadLine();
        }

        private static int fib(int n)
        {
            if (n == 0 || n == 1)
            {
                return n;
            }

            return fib(n - 1) + fib(n - 2);
        }
    }
}
