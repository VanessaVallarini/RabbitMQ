﻿using MediatR;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RabbitMQ2.Application.Queries.GetLastPayments
{
    public class GetLastPaymentsQuery : IRequest<List<GetLastPaymentsViewModel>>
    {
        public GetLastPaymentsQuery(int amount)
        {
            Amount = amount;
        }

        [Required]
        public int Amount { get; private set; }
    }
}