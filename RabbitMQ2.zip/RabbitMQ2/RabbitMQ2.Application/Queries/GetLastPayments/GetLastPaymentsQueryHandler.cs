﻿using MediatR;
using RabbitMQ2.Core.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RabbitMQ2.Application.Queries.GetLastPayments
{
    public class GetLastPaymentsQueryHandler : IRequestHandler<GetLastPaymentsQuery, List<GetLastPaymentsViewModel>>
    {
        private readonly IPaymentRepository _paymentRepository;

        public GetLastPaymentsQueryHandler(IPaymentRepository paymentRepository)
        {
            _paymentRepository = paymentRepository;
        }

        public async Task<List<GetLastPaymentsViewModel>> Handle(GetLastPaymentsQuery request, CancellationToken cancellationToken)
        {
            if (_paymentRepository == null) throw new Exception("Ocorreu um erro inesperado. Tente novamente!");

            var payments = await _paymentRepository.GetLastPayments(request.Amount);

            if (payments.Count() == 0) throw new Exception("Não há pagamentos registrados");

            var getLastPaymentsViewModel = payments
                .Select(p => new GetLastPaymentsViewModel(p.Id, p.AmountToPay, p.CardNumber, p.Name))
                .ToList();

            return getLastPaymentsViewModel;
        }
    }
}
