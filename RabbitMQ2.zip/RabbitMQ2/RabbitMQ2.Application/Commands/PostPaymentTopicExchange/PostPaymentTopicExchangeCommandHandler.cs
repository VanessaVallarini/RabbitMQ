﻿using MediatR;
using RabbitMQ2.Core.Entities;
using RabbitMQ2.Core.Repositories;
using RabbitMQ2.Core.ServiceBus;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RabbitMQ2.Application.Commands.PostPaymentTopicExchange
{
    public class PostPaymentTopicExchangeCommandHandler : IRequestHandler<PostPaymentTopicExchangeCommand, int>
    {
        private readonly IPaymentRepository _paymentRepository;
        private readonly IRabbitMQRepository _rabbitMQRepository;

        public PostPaymentTopicExchangeCommandHandler(IPaymentRepository paymentRepository, IRabbitMQRepository rabbitMQRepository)
        {
            _paymentRepository = paymentRepository;
            _rabbitMQRepository = rabbitMQRepository;
        }

        public async Task<int> Handle(PostPaymentTopicExchangeCommand request, CancellationToken cancellationToken)
        {
            if (_paymentRepository == null) throw new Exception("Ocorreu um erro inesperado. Tente novamente!");
            if (_rabbitMQRepository == null) throw new Exception("Ocorreu um erro inesperado. Tente novamente!");

            var payment = new Payment(request.AmountToPay, request.CardNumber, request.Name);
            await _paymentRepository.AddAsync(payment);

            _rabbitMQRepository.SendTopicExchange(payment);
            _rabbitMQRepository.Close();

            return payment.Id;
        }
    }
}
