﻿using MediatR;
using System.ComponentModel.DataAnnotations;

namespace RabbitMQ2.Application.Commands.PostPaymentStandardExchange
{
    public class PostPaymentStandardExchangeCommand : IRequest<int>
    {
        [Required]
        public decimal AmountToPay { get; set; }
        [Required]
        public string CardNumber { get; set; }
        [Required]
        public string Name { get; set; }
    }
}
