﻿using MediatR;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace RabbitMQ2.Application.Commands.PostPaymentDirectExchange
{
    public class PostPaymentDirectExchangeCommand : IRequest<int>
    {
        [Required]
        public decimal AmountToPay { get; set; }
        [Required]
        public string CardNumber { get; set; }
        [Required]
        public string Name { get; set; }
    }
}