﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading;

namespace TopicExchange
{
    //Embora o uso da troca direta tenha melhorado nosso sistema, ele ainda tem limitações -
    //não pode fazer roteamento com base em vários critérios.
    //As mensagens enviadas para uma troca de tópico não podem ter uma routing_key arbitrária -
    //deve ser uma lista de palavras, delimitada por pontos. 
    //A chave de ligação também deve estar no mesmo formato. A lógica por trás da troca de tópicos é
    //semelhante a uma direta - uma mensagem enviada com uma chave de roteamento específica será
    //entregue a todas as filas vinculadas a uma chave de ligação correspondente.
    //No entanto, existem dois casos especiais importantes para chaves de ligação:
    //* (estrela) pode substituir exatamente uma palavra.
    //# (hash) pode substituir zero ou mais palavras.
    //A troca de tópicos é poderosa e pode se comportar como outras trocas.
    //Quando uma fila é vinculada com a chave de ligação " # " (hash) - ela receberá todas as mensagens,
    //independentemente da chave de roteamento - como na troca de fanout.
    //Quando os caracteres especiais " * " (estrela) e " # " (hash) não são usados ​​nas ligações,
    //a troca de tópico se comporta como uma direta.
    public class TopicExchange
    {
        private static ConnectionFactory _factory;
        private static IConnection _connection;
        private static IModel channel;

        //nome da troca
        private const string NameTopicExchange = "Topic_ExampleExchange";
        //nomes das 3 filas
        private const string QueueNameCardPayment = "CardPaymentTopic_Queue"; //fila de pagamentos
        private const string QueueNamePurchaseOrder = "PurchaseOrderTopic_Queue";//fila de ordem de pedidos
        private const string QueueNameAll = "AllTopic_Queue"; //fila de auditoria e contas
        //rotas
        private const string route1 = "payment.card"; //fila de auditoria e contas
        private const string route2 = "payment.purchaseorder"; //fila de auditoria e contas
        private const string route3 = "payment.*"; //fila de auditoria e contas

        public static void ReceiveAllMessages()
        {
            _factory = new ConnectionFactory { HostName = "localhost", UserName = "guest", Password = "guest" };
            _connection = _factory.CreateConnection();
            channel = _connection.CreateModel();

            Console.WriteLine("Conectado com o MQ ...");

            var datasource = @"(localdb)\MSSQLLocalDB";//your server
            var database = "Logs"; //your database name
            var username = "vanessaichikawa"; //username of server to connect
            var password = "m@CYc0cAF&"; //password

            //your connection string 
            string connString = @"Data Source=" + datasource + ";Initial Catalog="
                        + database + ";Persist Security Info=True;User ID=" + username + ";Password=" + password;

            //criando a troca
            channel.ExchangeDeclare(exchange: NameTopicExchange, type: ExchangeType.Topic);

            //criando a fila
            channel.QueueDeclare(QueueNameAll, true, false, false, null);

            //vinculando a fila na troca utilizando a chave de roteamento payment.* (ou seja, todas as mensagens que iniciem com payment)
            channel.QueueBind(QueueNameAll, NameTopicExchange, route3);

            //Isso diz ao RabbitMQ para não dar mais de uma mensagem a um trabalhador de cada vez.
            //Ou, em outras palavras, não despache uma nova mensagem para um trabalhador até que ele
            //processe e reconheça a anterior. Em vez disso, ele o despachará para o próximo trabalhador
            //que ainda não estiver ocupado.
            channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

            int messageCount = Convert.ToInt16(channel.MessageCount(QueueNameAll));
            Console.WriteLine("Quantidade de mansagens na fila: {0}", messageCount);

            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (sender, e) =>
            {

                var body = e.Body.ToArray();

                var message = Encoding.UTF8.GetString(body);

                //apenas para simular um tempo maior de processamento
                int dots = message.Split('.').Length - 1;
                Thread.Sleep(dots * 1000);

                Console.WriteLine(" Mensagem recebida: {0}", message);

                //armazenando no banco de dados
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    String query = "INSERT INTO Logs(Message, TypeExchange) VALUES(@message, @typeExchange)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@message", message.ToString().Trim());

                        command.Parameters.AddWithValue("@typeExchange", QueueNameAll);

                        connection.Open();

                        int result = command.ExecuteNonQuery();

                        if (result < 0)
                            Console.WriteLine("Erro ao inserir no banco de dados!");
                    }

                    Console.WriteLine("Mensagem recebida (mensagem, rota): {0}, {1}", message, route3);
                }

                //apenas após armazenar a mensagem no banco é que eu informo o RabbitMQ que estou
                //pronto para receber mais mensagens
                channel.BasicAck(deliveryTag: e.DeliveryTag, multiple: false);
                Console.WriteLine("Mensagem confirmada!");
            };

            channel.BasicConsume(QueueNameAll, false, consumer);
            //false: se vou esperar uma mensagem de confirmação. Neste exemplo não estamos enviando
            //um reconhecimento da mensagem, portanto é false
            Console.ReadLine();
        }

        public static void ReceivePurchaseOrdersMessages()
        {
            _factory = new ConnectionFactory { HostName = "localhost", UserName = "guest", Password = "guest" };
            _connection = _factory.CreateConnection();
            channel = _connection.CreateModel();

            Console.WriteLine("Conectado com o MQ ...");

            var datasource = @"(localdb)\MSSQLLocalDB";//your server
            var database = "Logs"; //your database name
            var username = "vanessaichikawa"; //username of server to connect
            var password = "m@CYc0cAF&"; //password

            //your connection string 
            string connString = @"Data Source=" + datasource + ";Initial Catalog="
                        + database + ";Persist Security Info=True;User ID=" + username + ";Password=" + password;

            //criando a troca
            channel.ExchangeDeclare(exchange: NameTopicExchange, type: ExchangeType.Topic);

            //criando a fila
            channel.QueueDeclare(QueueNamePurchaseOrder, true, false, false, null);

            //vinculando a fila na troca utilizando a chave de roteamento payment.* (ou seja, todas as mensagens que iniciem com payment)
            channel.QueueBind(QueueNamePurchaseOrder, NameTopicExchange, route2);

            //Isso diz ao RabbitMQ para não dar mais de uma mensagem a um trabalhador de cada vez.
            //Ou, em outras palavras, não despache uma nova mensagem para um trabalhador até que ele
            //processe e reconheça a anterior. Em vez disso, ele o despachará para o próximo trabalhador
            //que ainda não estiver ocupado.
            channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

            int messageCount = Convert.ToInt16(channel.MessageCount(QueueNamePurchaseOrder));
            Console.WriteLine("Quantidade de mansagens na fila: {0}", messageCount);

            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (sender, e) =>
            {

                var body = e.Body.ToArray();

                var message = Encoding.UTF8.GetString(body);

                //apenas para simular um tempo maior de processamento
                int dots = message.Split('.').Length - 1;
                Thread.Sleep(dots * 1000);

                Console.WriteLine(" Mensagem recebida: {0}", message);

                //armazenando no banco de dados
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    String query = "INSERT INTO Logs(Message, TypeExchange) VALUES(@message, @typeExchange)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@message", message.ToString().Trim());

                        command.Parameters.AddWithValue("@typeExchange", QueueNamePurchaseOrder);

                        connection.Open();

                        int result = command.ExecuteNonQuery();

                        if (result < 0)
                            Console.WriteLine("Erro ao inserir no banco de dados!");
                    }

                    Console.WriteLine("Mensagem recebida (mensagem, rota): {0}, {1}", message, route2);
                }

                //apenas após armazenar a mensagem no banco é que eu informo o RabbitMQ que estou
                //pronto para receber mais mensagens
                channel.BasicAck(deliveryTag: e.DeliveryTag, multiple: false);
                Console.WriteLine("Mensagem confirmada!");
            };

            channel.BasicConsume(QueueNamePurchaseOrder, false, consumer);
            //false: se vou esperar uma mensagem de confirmação. Neste exemplo não estamos enviando
            //um reconhecimento da mensagem, portanto é false
            Console.ReadLine();
        }

        public static void ReceivePaymentsMessages()
        {
            _factory = new ConnectionFactory { HostName = "localhost", UserName = "guest", Password = "guest" };
            _connection = _factory.CreateConnection();
            channel = _connection.CreateModel();

            Console.WriteLine("Conectado com o MQ ...");

            var datasource = @"(localdb)\MSSQLLocalDB";//your server
            var database = "Logs"; //your database name
            var username = "vanessaichikawa"; //username of server to connect
            var password = "m@CYc0cAF&"; //password

            //your connection string 
            string connString = @"Data Source=" + datasource + ";Initial Catalog="
                        + database + ";Persist Security Info=True;User ID=" + username + ";Password=" + password;

            //criando a troca
            channel.ExchangeDeclare(exchange: NameTopicExchange, type: ExchangeType.Topic);

            //criando a fila
            channel.QueueDeclare(QueueNameCardPayment, true, false, false, null);

            //vinculando a fila na troca utilizando a chave de roteamento payment.* (ou seja, todas as mensagens que iniciem com payment)
            channel.QueueBind(QueueNameCardPayment, NameTopicExchange, route1);

            //Isso diz ao RabbitMQ para não dar mais de uma mensagem a um trabalhador de cada vez.
            //Ou, em outras palavras, não despache uma nova mensagem para um trabalhador até que ele
            //processe e reconheça a anterior. Em vez disso, ele o despachará para o próximo trabalhador
            //que ainda não estiver ocupado.
            channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

            int messageCount = Convert.ToInt16(channel.MessageCount(QueueNameCardPayment));
            Console.WriteLine("Quantidade de mansagens na fila: {0}", messageCount);

            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (sender, e) =>
            {

                var body = e.Body.ToArray();

                var message = Encoding.UTF8.GetString(body);

                //apenas para simular um tempo maior de processamento
                int dots = message.Split('.').Length - 1;
                Thread.Sleep(dots * 1000);

                Console.WriteLine(" Mensagem recebida: {0}", message);

                //armazenando no banco de dados
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    String query = "INSERT INTO Logs(Message, TypeExchange) VALUES(@message, @typeExchange)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@message", message.ToString().Trim());

                        command.Parameters.AddWithValue("@typeExchange", QueueNameCardPayment);

                        connection.Open();

                        int result = command.ExecuteNonQuery();

                        if (result < 0)
                            Console.WriteLine("Erro ao inserir no banco de dados!");
                    }

                    Console.WriteLine("Mensagem recebida (mensagem, rota): {0}, {1}", message, route1);
                }

                //apenas após armazenar a mensagem no banco é que eu informo o RabbitMQ que estou
                //pronto para receber mais mensagens
                channel.BasicAck(deliveryTag: e.DeliveryTag, multiple: false);
                Console.WriteLine("Mensagem confirmada!");
            };

            channel.BasicConsume(QueueNameCardPayment, false, consumer);
            //false: se vou esperar uma mensagem de confirmação. Neste exemplo não estamos enviando
            //um reconhecimento da mensagem, portanto é false
            Console.ReadLine();
        }
    }
}
