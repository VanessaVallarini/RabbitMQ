﻿using RabbitMQ.Client;
using System;

namespace TopicExchange
{
    class Program
    {
        static void Main(string[] args)
        {
            TopicExchange.ReceiveAllMessages();

            //TopicExchange.ReceivePurchaseOrdersMessages();

            //TopicExchange.ReceivePaymentsMessages();
        }
    }
}
