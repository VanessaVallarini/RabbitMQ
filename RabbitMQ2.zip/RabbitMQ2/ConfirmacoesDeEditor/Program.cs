﻿using RabbitMQ.Client;
using System;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;

namespace ConfirmacoesDeEditor
{
    //O editor confirma que é uma extensão do RabbitMQ para implementar uma publicação confiável.Quando as confirmações do editor são habilitadas em um canal,
    //as mensagens que o cliente publica são confirmadas de forma assíncrona pelo corretor, o que significa que foram atendidas no lado do servidor.
    //As confirmações do editor estão ativadas no nível do canal com o método ConfirmSelect
    public class Program
    {
        private const int MESSAGE_COUNT = 50_000;

        static void Main(string[] args)
        {
            PublishMessagesIndividually();
            PublishMessagesInBatch();
            HandlePublishConfirmsAsynchronously();
        }

        private static IConnection CreateConnection()
        {
            var factory = new ConnectionFactory { HostName = "localhost", UserName = "guest", Password = "guest" };
            return factory.CreateConnection();
        }

        //Estratégia nº 1: publicar mensagens individualmente e aguardar sincronicamente por sua confirmação
        //Publicamos uma mensagem e aguardamos sua confirmação com o método WaitForConfirmsOrDie (TimeSpan) .
        //O método retorna assim que a mensagem for confirmada. Se a mensagem não for confirmada dentro do tempo limite ou se for nacked
        //(significando que o corretor não pôde cuidar dela por algum motivo), o método lançará uma exceção.
        //O tratamento da exceção geralmente consiste em registrar uma mensagem de erro e / ou tentar novamente o envio da mensagem.
        //Essa técnica é muito direta, mas também tem uma grande desvantagem: ela retarda significativamente a publicação , pois a confirmação de uma mensagem bloqueia a
        //publicação de todas as mensagens subsequentes.Essa abordagem não vai entregar uma taxa de transferência de mais do que algumas centenas de mensagens publicadas por segundo.
        //As confirmações do editor são assíncronas?
        //O código espera de forma síncrona até que a mensagem seja confirmada.
        //O cliente realmente recebe confirmações de forma assíncrona e desbloqueia a chamada para WaitForConfirmsOrDie
        //Pense em WaitForConfirmsOrDie como um auxiliar síncrono que depende de notificações assíncronas.
        private static void PublishMessagesIndividually()
        {
            using (var connection = CreateConnection())
            using (var channel = connection.CreateModel())
            {
                // declare a server-named queue
                var queueName = channel.QueueDeclare(queue: "").QueueName;
                channel.ConfirmSelect();

                var timer = new Stopwatch();
                timer.Start();
                for (int i = 0; i < MESSAGE_COUNT; i++)
                {
                    var body = Encoding.UTF8.GetBytes(i.ToString());
                    channel.BasicPublish(exchange: "", routingKey: queueName, basicProperties: null, body: body);
                    channel.WaitForConfirmsOrDie(new TimeSpan(0, 0, 5));
                }
                timer.Stop();
                Console.WriteLine($"Publicou {MESSAGE_COUNT:N0} mensagens individualmente em {timer.ElapsedMilliseconds:N0} ms");
            }
        }

        //Estratégia nº 2: Publicação de mensagens em lotes
        //Podemos publicar um lote de mensagens e esperar que todo esse lote seja confirmado.O exemplo a seguir usa um lote de 100.
        //Esperar que um lote de mensagens seja confirmado melhora drasticamente o rendimento do que esperar por uma confirmação para uma mensagem individual
        //(até 20-30 vezes com um nó RabbitMQ remoto). Uma desvantagem é que não sabemos exatamente o que deu errado em caso de falha, então podemos ter que manter um
        //lote inteiro na memória para registrar algo significativo ou publicar as mensagens novamente.E essa solução ainda é síncrona, por isso bloqueia a publicação de mensagens.
        private static void PublishMessagesInBatch()
        {
            using (var connection = CreateConnection())
            using (var channel = connection.CreateModel())
            {
                // declare a server-named queue
                var queueName = channel.QueueDeclare(queue: "").QueueName;
                channel.ConfirmSelect();

                var batchSize = 100;
                var outstandingMessageCount = 0;
                var timer = new Stopwatch();
                timer.Start();
                for (int i = 0; i < MESSAGE_COUNT; i++)
                {
                    var body = Encoding.UTF8.GetBytes(i.ToString());
                    channel.BasicPublish(exchange: "", routingKey: queueName, basicProperties: null, body: body);
                    outstandingMessageCount++;

                    if (outstandingMessageCount == batchSize)
                    {
                        channel.WaitForConfirmsOrDie(new TimeSpan(0, 0, 5));
                        outstandingMessageCount = 0;
                    }
                }

                if (outstandingMessageCount > 0)
                    channel.WaitForConfirmsOrDie(new TimeSpan(0, 0, 5));

                timer.Stop();
                Console.WriteLine($"Publicou {MESSAGE_COUNT:N0} mensagens em lote em {timer.ElapsedMilliseconds:N0} ms");
            }
        }

        //Estratégia nº 3: Tratamento de confirmações do editor de maneira assíncrona
        //O corretor confirma as mensagens publicadas de forma assíncrona, basta registrar um retorno de chamada no cliente para ser notificado dessas confirmações.
        //Existem 2 retornos de chamada: um para mensagens confirmadas e outro para mensagens não enviadas(mensagens que podem ser consideradas perdidas pelo corretor).
        //Ambos os retornos de chamada têm um parâmetro EventArgs(ea ) correspondente contendo uma:
            //etiqueta de entrega: o número de sequência que identifica a mensagem confirmada ou nack-ed.
            //múltiplo: este é um valor booleano.Se falso, apenas uma mensagem é confirmada / descompactada; se verdadeira, todas as mensagens com um número de sequência menor ou
            //igual são confirmadas / descompactadas.
        //O número de sequência pode ser obtido com o NextPublishSeqNo antes da publicação
        //Uma maneira simples de correlacionar mensagens com o número de sequência consiste em usar um dicionário.
        //Precisamos limpar este dicionário quando as confirmações chegam e fazer algo como registrar um aviso quando as mensagens são nacked.
        //O exemplo anterior contém um retorno de chamada que limpa o dicionário quando a confirmação chega.Observe que este retorno de chamada lida com confirmações únicas e
        //múltiplas.Este retorno de chamada é usado quando a confirmação chega (Channel # BasicAcks ). O retorno de chamada para mensagens nack-ed recupera o corpo da mensagem e
        //emite um aviso. Em seguida, ele reutiliza o retorno de chamada anterior para limpar o dicionário de confirmações pendentes (se as mensagens forem confirmadas ou não,
        //suas entradas correspondentes no dicionário devem ser removidas).
        //Como rastrear confirmações pendentes?
        //Nossos exemplos usam um ConcurrentDictionary para rastrear confirmações pendentes.Essa estrutura de dados é conveniente por vários motivos:
            //Ele permite correlacionar facilmente um número de sequência com uma mensagem (sejam quais forem os dados da mensagem)
            //Limpar facilmente as entradas até um determinado id de sequência(para lidar com várias confirmações / nacks).
            //Ele suporta acesso simultâneo, porque os retornos de chamada de confirmação são chamados em um thread de propriedade da biblioteca cliente,
            //que deve ser mantido diferente do thread de publicação.

        //Resumindo, lidar com confirmações do editor de maneira assíncrona geralmente requer as seguintes etapas:
            //Correlacionar o número de sequência de publicação com uma mensagem.
            //Registrar que os ouvintes no canal serão notificados quando os acks / nacks do editor chegarem para realizar as ações apropriadas, como registrar ou publicar novamente
            //uma mensagem nack-ed.O mecanismo de correlação de número de sequência para mensagem também pode exigir alguma limpeza durante esta etapa.
            //Rastreie o número da sequência de publicação antes de publicar uma mensagem.
            //Re-publicar mensagens nack-ed?
            //Pode ser tentador publicar novamente uma mensagem nack-ed do retorno de chamada correspondente, mas isso deve ser evitado, pois os retornos de chamada de confirmação
            //são despachados em um thread de E / S onde os canais não devem fazer operações. Uma solução melhor consiste em enfileirar a mensagem em uma fila na memória que é
            //pesquisada por um thread de publicação.

        //Resumo
        //Certificar-se de que as mensagens publicadas chegam ao broker pode ser essencial em alguns aplicativos.
        //O editor confirma é um recurso do RabbitMQ que ajuda a atender a esse requisito.
        //As confirmações do editor são assíncronas por natureza, mas também é possível manipulá-las de maneira síncrona.
        //Não há uma maneira definitiva de implementar as confirmações do editor, isso geralmente se resume às restrições no aplicativo e no sistema geral. As técnicas típicas são:
            //publicar mensagens individualmente, aguardando a confirmação de forma síncrona: taxa de transferência simples, mas muito limitada.
            //publicação de mensagens em lote, aguardando a confirmação síncrona de um lote: taxa de transferência simples e razoável, mas difícil de raciocinar sobre quando algo
            //dá errado.
            //manuseio assíncrono: melhor desempenho e aproveitamento de recursos, bom controle em caso de erro, mas pode estar envolvido para implementar corretamente.
        private static void HandlePublishConfirmsAsynchronously()
        {
            using (var connection = CreateConnection())
            using (var channel = connection.CreateModel())
            {
                // declare a server-named queue
                var queueName = channel.QueueDeclare(queue: "").QueueName;
                channel.ConfirmSelect();

                //correlacionar mensagens com o número de sequência
                var outstandingConfirms = new ConcurrentDictionary<ulong, string>();

                void cleanOutstandingConfirms(ulong sequenceNumber, bool multiple)
                {
                    if (multiple)
                    {
                        var confirmed = outstandingConfirms.Where(k => k.Key <= sequenceNumber);
                        foreach (var entry in confirmed)
                            outstandingConfirms.TryRemove(entry.Key, out _);
                    }
                    else
                        outstandingConfirms.TryRemove(sequenceNumber, out _);
                }
                //limpar este dicionário quando as confirmações chegam
                channel.BasicAcks += (sender, ea) => cleanOutstandingConfirms(ea.DeliveryTag, ea.Multiple);
                //registrar um aviso quando as mensagens são nacked
                channel.BasicNacks += (sender, ea) =>
                {
                    outstandingConfirms.TryGetValue(ea.DeliveryTag, out string body);
                    Console.WriteLine($"Mensagem com corpo {body} foi nack-ed. Número de sequência: {ea.DeliveryTag}, múltiplo: {ea.Multiple}");
                    cleanOutstandingConfirms(ea.DeliveryTag, ea.Multiple);
                };

                var timer = new Stopwatch();
                timer.Start();
                for (int i = 0; i < MESSAGE_COUNT; i++)
                {
                    var body = i.ToString();
                    //número de sequência da mensagem #NextPublishSeqNo
                    outstandingConfirms.TryAdd(channel.NextPublishSeqNo, i.ToString());
                    channel.BasicPublish(exchange: "", routingKey: queueName, basicProperties: null, body: Encoding.UTF8.GetBytes(body));
                }

                if (!WaitUntil(60, () => outstandingConfirms.IsEmpty))
                    throw new Exception("Todas as mensagens não puderam ser confirmadas em 60 segundos");

                timer.Stop();
                Console.WriteLine($"Publicou {MESSAGE_COUNT:N0} mensagens e tratou confirmada de forma assíncrona {timer.ElapsedMilliseconds:N0} ms");
            }
        }

        private static bool WaitUntil(int numberOfSeconds, Func<bool> condition)
        {
            int waited = 0;
            while (!condition() && waited < numberOfSeconds * 1000)
            {
                Thread.Sleep(100);
                waited += 100;
            }

            return condition();
        }
    }
}
