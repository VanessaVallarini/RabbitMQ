﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading;

namespace StandardExchange
{
    public class StandardExchange
    {
        public static void Consume(IModel channel)
        {
            Console.WriteLine("Conectado com o MQ ...");

            var queueName = "StandardQueue_ExampleQueue";

            var datasource = @"(localdb)\MSSQLLocalDB";//your server
            var database = "Logs"; //your database name
            var username = "vanessaichikawa"; //username of server to connect
            var password = "m@CYc0cAF&"; //password

            //your connection string 
            string connString = @"Data Source=" + datasource + ";Initial Catalog="
                        + database + ";Persist Security Info=True;User ID=" + username + ";Password=" + password;

            //declarando a fila novamente. Se a fila já existe só retorna os dados da fila e não a
            //declara novamente
            //para ter certeza de que a fila sobreviverá a uma reinicialização do nó RabbitMQ:
            //durable: true
            channel.QueueDeclare(queueName,
                durable: true,
                exclusive: false,
                autoDelete: false,
                arguments: null);

            //Isso diz ao RabbitMQ para não dar mais de uma mensagem a um trabalhador de cada vez.
            //Ou, em outras palavras, não despache uma nova mensagem para um trabalhador até que ele
            //processe e reconheça a anterior. Em vez disso, ele o despachará para o próximo trabalhador
            //que ainda não estiver ocupado.
            channel.BasicQos(prefetchSize: 0, prefetchCount: 1, global: false);

            int messageCount = Convert.ToInt16(channel.MessageCount(queueName));
            Console.WriteLine("Quantidade de mansagens na fila: {0}", messageCount);

            //consumindo as mensagens
            var consumer = new EventingBasicConsumer(channel);

            consumer.Received += (sender, e) => {

                var body = e.Body.ToArray();

                var message = Encoding.UTF8.GetString(body);

                //apenas para simular um tempo maior de processamento
                int dots = message.Split('.').Length - 1;
                Thread.Sleep(dots * 1000);

                Console.WriteLine(" Mensagem recebida: {0}", message);

                //armazenando no banco de dados
                using (SqlConnection connection = new SqlConnection(connString))
                {
                    String query = "INSERT INTO Logs(Message, TypeExchange) VALUES(@message, @typeExchange)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@message", message.ToString().Trim());

                        command.Parameters.AddWithValue("@typeExchange", queueName);

                        connection.Open();

                        int result = command.ExecuteNonQuery();

                        if (result < 0)
                            Console.WriteLine("Erro ao inserir a mensagem no banco de dados!");
                    }
                }

                //apenas após armazenar a mensagem no banco é que eu informo o RabbitMQ que estou
                //pronto para receber mais mensagens
                channel.BasicAck(deliveryTag: e.DeliveryTag, multiple: false);
                Console.WriteLine("Mensagem confirmada!");
            };

            channel.BasicConsume(queueName, false, consumer);
            //false: se vou esperar uma mensagem de confirmação. Neste exemplo não estamos enviando
            //um reconhecimento da mensagem, portanto é false
            Console.ReadLine();
        }
    }
}
