﻿using Microsoft.EntityFrameworkCore;
using RabbitMQ2.Core.Entities;

namespace RabbitMQ2.Infrastructure
{
    public class RabbitMQDbContext : DbContext
    {
        public RabbitMQDbContext(DbContextOptions<RabbitMQDbContext> options)
            : base(options)//passando as infromações de conexões para o DbContext
        {

        }

        public DbSet<Payment> Payments { get; set; }
    }
}