﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ2.Core.Entities;
using RabbitMQ2.Core.ServiceBus;
using System.Text;

namespace RabbitMQ2.Infrastructure.ServiceBus
{
    public class RabbitMQRepository : IRabbitMQRepository
    {
        //criando a conexão com o RabbitMQ
        private static ConnectionFactory _factory;
        private static IConnection _connection;
        private static IModel _model;

        private const string QueueNameStandardExchange = "StandardQueue_ExampleQueue";

        private const string NameFanoutExchange = "Fanout_ExampleExchange";

        private const string NameDirectExchange = "Direct_ExampleExchange";

        private const string NameTopicExchange = "Topic_ExampleExchange";

        private const string QueueNameCardPayment = "CardPaymentTopic_Queue"; //fila de pagamentos
        private const string QueueNamePurchaseOrder = "PurchaseOrderTopic_Queue";//fila de ordem de pedidos
        private const string QueueNameAll = "AllTopic_Queue"; //fila de auditoria e contas

        private const string route1 = "payment.card"; //fila de auditoria e contas
        private const string route2 = "payment.purchaseorder"; //fila de auditoria e contas
        private const string route3 = "payment.*"; //fila de auditoria e contas

        public RabbitMQRepository()
        {
            _factory = new ConnectionFactory
            {
                HostName = "localhost",
                UserName = "guest",
                Password = "guest"
            };
            _connection = _factory.CreateConnection();
            _model = _connection.CreateModel();
        }

        public void Close()
        {
            _connection.Close();
        }

        public void SendStandardExchange(Payment payment)
        {
            _model.QueueDeclare(queue: QueueNameStandardExchange,
                                     durable: true,
                                     exclusive: false,
                                     autoDelete: false,
                                     arguments: null);
            //name: StandardQueue_ExampleQueue
            //para ter certeza de que a fila sobreviverá a uma reinicialização do nó RabbitMQ:
            //durable: true

            var json = JsonConvert.SerializeObject(payment);

            var body = Encoding.ASCII.GetBytes(json);

            //Agora precisamos marcar nossas mensagens como persistentes - definindo IBasicProperties.SetPersistent como true .
            var properties = _model.CreateBasicProperties();
            properties.Persistent = true;

            _model.BasicPublish(exchange: "",
                                     routingKey: QueueNameStandardExchange,
                                     basicProperties: properties,
                                     body: body);
        }

        public void SendFanoutExchange(Payment payment)
        {
            //criando a troca do tipo fanout
            _model.ExchangeDeclare(exchange: NameFanoutExchange, type: ExchangeType.Fanout);

            var json = JsonConvert.SerializeObject(payment);

            var body = Encoding.ASCII.GetBytes(json);

            _model.BasicPublish(exchange: NameFanoutExchange,
                                routingKey: "",
                                basicProperties: null,
                                body: body);
            //ao invés de criar uma fila criamos uma troca do tipo fanout
            //ou seja, qualquer consumidor que estiver ouvindo essa troca irá receber as mensagens
            //Assim, podemos enviar a mesma mensagem para várias filas
        }

        public void SendDirecExchange(Payment payment)
        {
            //criando a troca do tipo direct
            _model.ExchangeDeclare(exchange: NameDirectExchange, type: ExchangeType.Direct);

            var json = JsonConvert.SerializeObject(payment);

            var body = Encoding.ASCII.GetBytes(json);

            if (payment.Name == "pagamentos")
            {
                var route = "pagamentos";

                _model.BasicPublish(exchange: NameDirectExchange,
                                     routingKey: route,
                                     basicProperties: null,
                                     body: body);
            }
            else
            {
                var route = "cancelados";

                _model.BasicPublish(exchange: NameDirectExchange,
                                     routingKey: route,
                                     basicProperties: null,
                                     body: body);
            }

            //ao invés de criar uma fila criamos uma troca do tipo direct
            //ou seja, qualquer consumidor que estiver ouvindo essa troca irá receber as mensagens
            //Assim, podemos enviar a mesma mensagem para várias filas
            //a diferença desse modelo para o fanout é que podemos rotear as mensagens
            //aqui, todos os pagamentos com nome pagamentos eu estou enviando para a rota de pagamentos
            //os cancelados estão na rota de cancelados
            //assim, no momento de ler a troca, vamos ler apenas os pagamentos e não ler os cancelados
        }

        public void SendTopicExchange(Payment payment)
        {
            //criando a troca
            _model.ExchangeDeclare(exchange: NameTopicExchange, type: ExchangeType.Topic);

            //declarando as filas que queremos usar
            //true quer dizer que são durávis
            _model.QueueDeclare(QueueNameCardPayment, true, false, false, null);
            _model.QueueDeclare(QueueNamePurchaseOrder, true, false, false, null);
            _model.QueueDeclare(QueueNameAll, true, false, false, null);

            //ligando as filas às trocas (roteamento de tópicos)
            _model.QueueBind(QueueNameCardPayment, NameTopicExchange, route1);
            _model.QueueBind(QueueNamePurchaseOrder, NameTopicExchange, route2);
            _model.QueueBind(QueueNameAll, NameTopicExchange, route3);

            var json = JsonConvert.SerializeObject(payment);

            var body = Encoding.ASCII.GetBytes(json);

            //Agora precisamos marcar nossas mensagens como persistentes - definindo IBasicProperties.SetPersistent como true .
            var properties = _model.CreateBasicProperties();
            properties.Persistent = true;

            _model.BasicPublish(exchange: NameTopicExchange,
                                    routingKey: route1,
                                    basicProperties: properties,
                                    body: body);

            _model.BasicPublish(exchange: NameTopicExchange,
                                    routingKey: route2,
                                    basicProperties: properties,
                                    body: body);
        }
    }
}
