﻿using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using RabbitMQ2.Core.DTOs;
using RabbitMQ2.Core.Entities;
using RabbitMQ2.Core.Repositories;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RabbitMQ2.Infrastructure.Repositories
{
    public class PaymentRepository : IPaymentRepository
    {
        private readonly RabbitMQDbContext _dbContext;

        private readonly string _connectionString;

        public PaymentRepository(RabbitMQDbContext dbContext, IConfiguration configuration)
        {
            _dbContext = dbContext;
            _connectionString = configuration.GetConnectionString("RabbitMQDB");
        }

        public async Task AddAsync(Payment payment)
        {
            await _dbContext.Payments.AddAsync(payment);

            await _dbContext.SaveChangesAsync();
        }

        public async Task<List<PaymentDTO>> GetLastPayments(int amount)
        {
            using (var sqlConnection = new SqlConnection(_connectionString))
            {
                sqlConnection.Open();

                var script = "SELECT TOP "+ amount+" * FROM Payments order by 1 DESC";

                var courses = await sqlConnection.QueryAsync<PaymentDTO>(script);

                return courses.ToList();
            }
        }

        public async Task SaveChangesAsync()
        {
            await _dbContext.SaveChangesAsync();
        }
    }
}
