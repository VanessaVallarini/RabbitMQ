﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RabbitMQ2.Application.Queries.GetLastPayments;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Threading.Tasks;

namespace RabbitMQ2.API.Controllers
{
    [Route("api/payments")]
    public class GetLastPaymentsController : ControllerBase
    {
        private readonly IMediator _mediator;
        public GetLastPaymentsController(IMediator mediator)
        {
            _mediator = mediator;
        }


        [SwaggerResponse(StatusCodes.Status200OK)]
        [SwaggerResponse(StatusCodes.Status404NotFound)]
        [SwaggerResponse(StatusCodes.Status401Unauthorized)]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        [HttpGet("lastpayments/{amount}")]
        public async Task<IActionResult> GetLastPayments(int amount)
        {
            try
            {
                var query = new GetLastPaymentsQuery(amount);

                var result = await _mediator.Send(query);

                if (result == null) throw new Exception("Ocorreu um erro inesperado. Tente novamente!");

                return Ok(result);
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}
