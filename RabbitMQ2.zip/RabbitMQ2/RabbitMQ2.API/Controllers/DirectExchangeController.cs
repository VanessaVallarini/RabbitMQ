﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RabbitMQ2.Application.Commands.PostPaymentDirectExchange;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RabbitMQ2.API.Controllers
{
    [Route("api/directexchange")]
    public class DirectExchangeController : ControllerBase
    {
        private readonly IMediator _mediator;
        public DirectExchangeController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [SwaggerResponse(StatusCodes.Status201Created)]
        [SwaggerResponse(StatusCodes.Status204NoContent)]
        [SwaggerResponse(StatusCodes.Status400BadRequest)]
        [SwaggerResponse(StatusCodes.Status404NotFound)]
        [SwaggerResponse(StatusCodes.Status401Unauthorized)]
        [SwaggerResponse(StatusCodes.Status500InternalServerError)]
        [HttpPost("create")]
        public async Task<IActionResult> PostPayment([FromBody] PostPaymentDirectExchangeCommand command)
        {
            if (command.AmountToPay <= 0 || command.CardNumber == null || command.Name == null)
            {
                return BadRequest();
            }

            try
            {
                var id = await _mediator.Send(command);

                if (id == 0) throw new Exception("Não foi possível registrar esse pagamento! Tente novamente.");

                return NoContent();
            }
            catch (Exception ex)
            {
                return NotFound(ex.Message);
            }
        }
    }
}