﻿using Microsoft.Extensions.DependencyInjection;
using RabbitMQ2.Core.Repositories;
using RabbitMQ2.Core.ServiceBus;
using RabbitMQ2.Infrastructure.Repositories;
using RabbitMQ2.Infrastructure.ServiceBus;

namespace RabbitMQ2.API.Extensions
{
    public static class ServiceCollectionExtensions
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services.AddScoped<IPaymentRepository, PaymentRepository>();
            services.AddScoped<IRabbitMQRepository, RabbitMQRepository>();

            return services;
        }
    }
}
