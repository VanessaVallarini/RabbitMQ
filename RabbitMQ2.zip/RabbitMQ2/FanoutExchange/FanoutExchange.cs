﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using System.Threading;

namespace FanoutExchange
{
    //Diferente do Standard onde criamos uma fila de trabalho
    //onde cada mensagem era entregue a exatamente um trabalhador.
    //Neste exemplo, faremos algo completamente diferente - entregaremos uma mensagem a vários
    //consumidores.
    //e ao invés de usarmos apenas uma fila, vamos usar uma troca
    //Uma troca é uma coisa muito simples. Por um lado, ele recebe mensagens dos produtores e,
    //por outro, os empurra para as filas. A troca deve saber exatamente o que fazer com a mensagem
    //que recebe. Deve ser anexado a uma fila específica? Deve ser anexado a muitas filas?
    //Ou deve ser descartado. As regras para isso são definidas pelo tipo de troca .
    //Existem alguns tipos de troca disponíveis: direto , tópico , cabeçalhos e fanout .
    //Vamos nos concentrar no último - o fanout.
    //A troca de fanout é muito simples. Ele apenas transmite todas as mensagens que recebe para
    //todas as filas que conhece.
    public class FanoutExchange
    {
        private const string NameFanoutExchange = "Fanout_ExampleExchange";

        public static void Consume(IModel channel)
        {
            Console.WriteLine("Getting Connection ...");

            var datasource = @"(localdb)\MSSQLLocalDB";//your server
            var database = "Logs"; //your database name
            var username = "vanessaichikawa"; //username of server to connect
            var password = "m@CYc0cAF&"; //password

            //your connection string 
            string connString = @"Data Source=" + datasource + ";Initial Catalog="
                        + database + ";Persist Security Info=True;User ID=" + username + ";Password=" + password;

            //criando a troca
            channel.ExchangeDeclare(exchange: NameFanoutExchange, type: ExchangeType.Fanout);

            //criando uma fila temporária
            var queueName = channel.QueueDeclare().QueueName;

            //ligando a fila na troca
            channel.QueueBind(queue: queueName, exchange: NameFanoutExchange, routingKey: "");

            Console.WriteLine("Esperando por registros...");

            //consumindo as mensagens
            var consumer = new EventingBasicConsumer(channel);

            var before = 0;

            var ret = true;
            while (ret)
            {
                consumer.Received += (sender, e) =>
                {

                    var body = e.Body.ToArray();

                    var message = Encoding.UTF8.GetString(body);

                    var payment = JsonConvert.DeserializeObject<Payment>(message);
                    
                    if (payment.Id != before)
                    {
                        //armazenando no banco de dados
                        using (SqlConnection connection = new SqlConnection(connString))
                        {
                            String query = "INSERT INTO Logs(Message, TypeExchange) VALUES(@message, @typeExchange)";

                            using (SqlCommand command = new SqlCommand(query, connection))
                            {
                                command.Parameters.AddWithValue("@message", message.ToString().Trim());

                                command.Parameters.AddWithValue("@typeExchange", queueName);

                                connection.Open();

                                int result = command.ExecuteNonQuery();

                                if (result < 0)
                                    Console.WriteLine("Erro ao inserir no banco de dados!");
                            }

                            Console.WriteLine("Mensagem recebida: {0}", message);
                        }
                    }

                    before = payment.Id;
    
                };

                channel.BasicConsume(queueName, true, consumer);
                //false: se vou esperar uma mensagem de confirmação.
                //Neste exemplo não estamos enviando um reconhecimento da mensagem, portanto é true
            }
        }
    }
}
