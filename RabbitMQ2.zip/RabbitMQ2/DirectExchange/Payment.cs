﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DirectExchange
{
    public class Payment
    {
        public Payment(int id, decimal amountToPay, string cardNumber, string name)
        {
            Id = id;
            AmountToPay = amountToPay;
            CardNumber = cardNumber;
            Name = name;
        }

        public int Id { get; private set; }
        public decimal AmountToPay { get; private set; }
        public string CardNumber { get; private set; }
        public string Name { get; private set; }
    }
}
