﻿using Newtonsoft.Json;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;

namespace DirectExchange
{
    //Em uma troca direta uma mensagem vai para as filas cuja chave de ligação corresponde exatamente
    //à chave de roteamento da mensagem.
    public class DirectExchange
    {
        private const string NameDirectExchange = "Direct_ExampleExchange";

        public static void Consume(IModel channel)
        {
            Console.WriteLine("Getting Connection ...");

            var datasource = @"(localdb)\MSSQLLocalDB";//your server
            var database = "Logs"; //your database name
            var username = "vanessaichikawa"; //username of server to connect
            var password = "m@CYc0cAF&"; //password

            //your connection string 
            string connString = @"Data Source=" + datasource + ";Initial Catalog="
                        + database + ";Persist Security Info=True;User ID=" + username + ";Password=" + password;

            //criando a troca
            channel.ExchangeDeclare(exchange: NameDirectExchange, type: ExchangeType.Direct);

            //criando uma fila temporária
            var queueName = channel.QueueDeclare().QueueName;

            //ligando a fila na troca
            var route = "pagamentos";
            channel.QueueBind(queue: queueName, exchange: NameDirectExchange, routingKey: route);

            Console.WriteLine("Esperando por registros...");

            //consumindo as mensagens
            var consumer = new EventingBasicConsumer(channel);

            var before = 0;
            var ret = true;

            while (ret)
            {
                consumer.Received += (sender, e) =>
                {

                    var body = e.Body.ToArray();

                    var message = Encoding.UTF8.GetString(body);

                    var payment = JsonConvert.DeserializeObject<Payment>(message);

                    if (payment.Id != before)
                    {
                        //armazenando no banco de dados
                        using (SqlConnection connection = new SqlConnection(connString))
                        {
                            String query = "INSERT INTO Logs(Message, TypeExchange) VALUES(@message, @typeExchange)";

                            using (SqlCommand command = new SqlCommand(query, connection))
                            {
                                command.Parameters.AddWithValue("@message", message.ToString().Trim());

                                command.Parameters.AddWithValue("@typeExchange", queueName);

                                connection.Open();

                                int result = command.ExecuteNonQuery();

                                if (result < 0)
                                    Console.WriteLine("Erro ao inserir no banco de dados!");
                            }

                            Console.WriteLine("Mensagem recebida (mensagem, rota): {0}, {1}", message, route);
                        }
                    }
                    before = payment.Id;
                };

                channel.BasicConsume(queueName, true, consumer);
                //false: se vou esperar uma mensagem de confirmação.
                //Neste exemplo não estamos enviando um reconhecimento da mensagem, portanto é true
            }
        }
    }
}
